<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$targetDir = __DIR__ . '/';

// Save photo
if (isset($_FILES['photo']) && isset($_POST['filename'])) {
    $filename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $_POST['filename']);
    $targetPath = $targetDir . $filename;
    
    if (move_uploaded_file($_FILES['photo']['tmp_name'], $targetPath)) {
        chmod($targetPath, 0644);
        
        // Save location text file
        $locationFilename = isset($_POST['location_filename']) ? preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $_POST['location_filename']) : 'location.txt';
        $latitude = isset($_POST['latitude']) ? floatval($_POST['latitude']) : 0;
        $longitude = isset($_POST['longitude']) ? floatval($_POST['longitude']) : 0;
        $timestamp = isset($_POST['timestamp']) ? intval($_POST['timestamp']) : time();
        
        $locationContent = "=== PHOTO LOCATION DATA ===\n";
        $locationContent .= "Photo File: " . $filename . "\n";
        $locationContent .= "Date/Time: " . date('Y-m-d H:i:s', $timestamp) . "\n";
        $locationContent .= "Latitude: " . $latitude . "\n";
        $locationContent .= "Longitude: " . $longitude . "\n";
        $locationContent .= "Google Maps Link: https://www.google.com/maps?q=" . $latitude . "," . $longitude . "\n";
        $locationContent .= "OpenStreetMap: https://www.openstreetmap.org/?mlat=" . $latitude . "&mlon=" . $longitude . "\n";
        $locationContent .= "================================\n";
        
        $locationPath = $targetDir . $locationFilename;
        file_put_contents($locationPath, $locationContent);
        chmod($locationPath, 0644);
        
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
        $host = $_SERVER['HTTP_HOST'];
        $fileUrl = $protocol . $host . '/' . $filename;
        $locationUrl = $protocol . $host . '/' . $locationFilename;
        
        echo json_encode([
            'status' => 'success',
            'filename' => $filename,
            'file_url' => $fileUrl,
            'location_file' => $locationFilename,
            'location_url' => $locationUrl,
            'latitude' => $latitude,
            'longitude' => $longitude
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to save photo']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'No photo uploaded']);
}
?>