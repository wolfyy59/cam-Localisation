<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Get all image files
$photos = glob("*.{jpg,jpeg,png,gif,JPG,JPEG,PNG,GIF}", GLOB_BRACE);
// Get ALL text files that might contain location data
$locationFiles = array_merge(
    glob("location_*.txt", GLOB_BRACE),
    glob("*_location.txt", GLOB_BRACE),
    glob("*.loc.txt", GLOB_BRACE)
);
// Remove duplicates
$locationFiles = array_unique($locationFiles);

$photoList = [];
$locationList = [];

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'];

foreach ($photos as $photo) {
    $basename = basename($photo);
    if ($basename !== 'index.html' && $basename !== 'gallery.html') {
        $photoList[] = [
            'name' => $basename,
            'url' => $protocol . $host . '/' . $basename,
            'modified' => filemtime($photo)
        ];
    }
}

foreach ($locationFiles as $loc) {
    $basename = basename($loc);
    $locationList[] = [
        'name' => $basename,
        'url' => $protocol . $host . '/' . $basename,
        'modified' => filemtime($loc)
    ];
}

// Sort photos by modification time (newest first)
usort($photoList, function($a, $b) {
    return $b['modified'] - $a['modified'];
});

echo json_encode([
    'photos' => $photoList,
    'location_files' => $locationList,
    'total_photos' => count($photoList),
    'total_location_files' => count($locationList)
]);
?>