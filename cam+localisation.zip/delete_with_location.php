<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['filename'])) {
    echo json_encode(['status' => 'error', 'message' => 'No filename provided']);
    exit;
}

$filename = basename($data['filename']);
$filepath = __DIR__ . '/' . $filename;

// Find matching location file
$baseName = pathinfo($filename, PATHINFO_FILENAME);
$locationPattern = $baseName . '.txt';
$locationFiles = glob("location_*{$baseName}*.txt", GLOB_BRACE);
$deleted = 0;

if (file_exists($filepath) && is_file($filepath)) {
    if (unlink($filepath)) {
        $deleted++;
    }
}

foreach ($locationFiles as $locFile) {
    if (unlink($locFile)) {
        $deleted++;
    }
}

echo json_encode(['status' => 'success', 'deleted_count' => $deleted, 'message' => 'Files deleted']);
?>