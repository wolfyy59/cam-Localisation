<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$photos = glob("*.{jpg,jpeg,png,gif,JPG,JPEG,PNG,GIF}", GLOB_BRACE);
$locationFiles = glob("location_*.txt", GLOB_BRACE);
$deletedPhotos = 0;
$deletedLocs = 0;

foreach ($photos as $photo) {
    $basename = basename($photo);
    if ($basename !== 'index.html' && $basename !== 'gallery.html') {
        if (unlink($photo)) $deletedPhotos++;
    }
}

foreach ($locationFiles as $loc) {
    if (unlink($loc)) $deletedLocs++;
}

echo json_encode([
    'status' => 'success', 
    'deleted_photos' => $deletedPhotos,
    'deleted_locations' => $deletedLocs
]);
?>